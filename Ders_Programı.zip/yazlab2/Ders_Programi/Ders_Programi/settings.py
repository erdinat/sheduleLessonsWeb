INSTALLED_APPS = [
    'admin_interface',
    'colorfield',
    # 'jazzmin',
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    # Belki başka 3. parti uygulamalar
    'schedule.apps.ScheduleConfig',
    'django_extensions',
] 